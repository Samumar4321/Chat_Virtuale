/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chat_virtuale;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samum
 */
public class Gestore_Packet extends Thread {

    //List<DatagramPacket> packets;
    InetAddress lastIP;

    public Gestore_Packet() throws UnknownHostException {
        //packets = new ArrayList<DatagramPacket>();
        //lastIP =  InetAddress.getByName("10.0.0.12");;
        lastIP = null;
    }

    /*synchronized public void add(DatagramPacket p) {
        packets.add(p);
    }*/
    public void execute(DatagramPacket p) throws UnknownHostException {
        if (lastIP == null || p.getAddress() == lastIP) {
            byte[] buffer = p.getData();
            String action = new String(buffer).split(";")[0];
            System.out.println("ACTION: " + action);
            lastIP = p.getAddress();
            switch (action) {
                case "a": {
                    try {
                        Messaggio_Apertura ma = new Messaggio_Apertura(p);
                        ma.execute();
                    } catch (SocketException ex) {
                        Logger.getLogger(Gestore_Packet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    break;
                }
                case "c": {
                    lastIP = null;
                    break;
                }
                case "m": {
                    break;
                }
                case "y": {
                    try {
                        Messaggio_RispApertura mar = new Messaggio_RispApertura(p);
                        mar.execute();
                    } catch (SocketException ex) {
                        Logger.getLogger(Gestore_Packet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                }
                case "n": {
                    lastIP = null;
                    break;
                }

            }
        } else {
            System.out.println("Uscito dallo switch senza gestire il pacchetto");
        }
    }
    /*  @Override
    public void run() {
        System.out.println("Startato");
        while (true) {

            if (packets.size() > 0) {
                System.out.println("Switch");
                byte[] buffer = packets.get(0).getData();
                String action = new String(buffer).split(";")[0];
                System.out.println("ACTION: " + action);
                switch (action) {
                    case "a": {
                        try {
                            Messaggio_Apertura ma = new Messaggio_Apertura(packets.get(0));
                            ma.execute();
                        } catch (SocketException ex) {
                            Logger.getLogger(Gestore_Packet.class.getName()).log(Level.SEVERE, null, ex);
                        }

                        break;
                    }
                    case "c": {
                        break;
                    }
                    case "m": {
                        break;
                    }
                    case "y": {
                        try {
                            Messaggio_RispApertura mar = new Messaggio_RispApertura(packets.get(0));
                            mar.execute();
                        } catch (SocketException ex) {
                            Logger.getLogger(Gestore_Packet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        break;
                    }
                    case "n": {
                        break;
                    }

                }
                packets.remove(0);
            }
        }
    }
     */
}
