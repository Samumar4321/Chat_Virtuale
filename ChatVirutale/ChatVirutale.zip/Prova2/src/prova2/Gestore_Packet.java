/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2;

import java.net.DatagramPacket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samum
 */
public class Gestore_Packet extends Thread {

    List<DatagramPacket> packets;

    public Gestore_Packet() {
        packets = new ArrayList<DatagramPacket>();
    }

    synchronized public void add(DatagramPacket p) {
        packets.add(p);
    }

    public void execute(DatagramPacket p) {
        byte[] buffer = p.getData();
        String action = new String(buffer).split(";")[0];
        System.out.println("ACTION: " + action);
        switch (action) {
            case "a": {
                try {
                    Messaggio_Apertura ma = new Messaggio_Apertura(p);
                    ma.execute();
                } catch (SocketException ex) {
                    Logger.getLogger(Gestore_Packet.class.getName()).log(Level.SEVERE, null, ex);
                }

                break;
            }
            case "c": {
                break;
            }
            case "m": {
                break;
            }
            case "y": {
                try {
                    Messaggio_RispApertura mar = new Messaggio_RispApertura(p);
                    mar.execute();
                } catch (SocketException ex) {
                    Logger.getLogger(Gestore_Packet.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
            case "n": {
                break;
            }

        }
    }
   
}
